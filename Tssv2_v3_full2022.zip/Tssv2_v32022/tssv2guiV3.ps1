﻿function update-parm {
    Param ([hashtable]$NamedParameters)
    return ($NamedParameters.GetEnumerator()|%{"-$($_.Key) `"$($_.Value)`""}) -join " "
}




## RUN THE MSDT LOG COLLECTION
[array]$options= "AcceptEula","AddDescription","Assist","BasicLog","CollectComponentLog","CollectDump","CollectEventLog","Crash","CrashMode","CustomETL","DebugMode","Discard","EnableCOMDebug","EtlOptions","EvtDaysBack","InputlogPath","LogFolderPath","MaxEvents","Mini","Mode","RemoteHosts","RemoteLogFolder","RemoteRun","RemoveAutoLogger","SkipSDPList","Status","StopWaitTimeInSec","Update","Version","WaitEvent"

  function scenario
{


#[array]$DropDownArray2 = "-SDP All","-SDP Apps","-SDP Cluster","-SDP CTS","-SDP DA","-SDP Dom","-SDP DPM","-SDP HyperV","-SDP mini","-SDP nano","-SDP Net","-SDP Perf","-SDP Print","-SDP RDS","-SDP Repro","-SDP RFL","-SDP S2D","-SDP SCCM","-SDP Setup","-SDP SQLbase","-SDP SQLconn","-SDP SQLmsdtc","-SDP SQLsetup","-SDP SUVP","-SDP VSS" 
# This Function Returns the Selected Value and Closes the Form
[array]$DropDownArray2 = "ADS_AccountLockout","ADS_Auth","ADS_Basic","ADS_ESR","ADS_OCSP","ADS_SBSL","DEV_Scn1","DEV_Scn2","DND_Servicing","NET_802Dot1x","NET_Auth","NET_BITS","NET_Bluetooth","NET_BranchCache","NET_Capture","NET_Container","NET_CSC","NET_DAcli","NET_DAsrv","NET_DFScli","NET_DFSsrv","NET_DHCPcli","NET_DHCPsrv","NET_DNScli","NET_DNSsrv","NET_Docker","NET_Firewall","NET_General","NET_HypHost","NET_IIS","NET_IPAM","NET_MBN","NET_MDM","NET_Miracast","NET_NCSI","NET_NETIO","NET_Netview","NET_NFScli","NET_NFSsrv","NET_NLB","NET_NPS","NET_PowerShell","NET_Proxy","NET_RAS","NET_RDMA","NET_RDScli","NET_RDSsrv","NET_RPC","NET_SBSL","NET_SdnNC","NET_SMB","NET_SMBcli","NET_SMBsrv","NET_SQLtrace","NET_UNChard","NET_VPN","NET_WebClient","NET_WebCliTTD","NET_WebIO","NET_WFP","NET_Winsock","NET_WIP","NET_WLAN","NET_WNV","NET_WorkFolders","PRF_Boot",  "PRF_Perflib","SHA_HypHost","SHA_HypVM","SHA_MScluster","UEX_Clipboard","UEX_Cortana","UEX_Logon","UEX_Photo","UEX_QuickAssist","UEX_Search","UEX_ServerManager","UEX_StartMenu","UEX_Store","UEX_Task","UEX_UWP","UEX_WinRM","UEX_WMI"





[void] [System.Reflection.Assembly]::LoadWithPartialName("System.Windows.Forms")
[void] [System.Reflection.Assembly]::LoadWithPartialName("System.Drawing")
function senditdown {
$script:Choice = $DropDown1.SelectedItem.ToString()
$Form.Close()
$script:final

set-location -Path $PSScriptRoot
$script2run = $pwd
$destination = Split-Path -Path $script2run -Parent
set-location $destination
$build1 = ".\TssV2.ps1" 
$script:final = $build1 + " -scenario"+ " $script:Choice"
 


}

function close-DropDown {
$script:Choice = $DropDown1.SelectedItem.ToString()

$Form.Close()


}

###BEGIN MSDT WINDOW  
$Form = New-Object System.Windows.Forms.Form

$Form.width = 1200
$Form.height = 400
$Form.Text = ”.\TssV2 GUI”
## DROPDOWN TO CHOOSE COURSE OF COMMANDS 
$DropDown1 = new-object System.Windows.Forms.ComboBox
$DropDown1.Location = new-object System.Drawing.Size(120,40)
$DropDown1.Size = new-object System.Drawing.Size(190,60)

ForEach ($Item in $DropDownArray2) {
[void] $DropDown1.Items.Add($Item)
}

$Form.Controls.Add($DropDown1)

$DropDownLabel = new-object System.Windows.Forms.Label
$DropDownLabel.Location = new-object System.Drawing.Size(20,40)
$DropDownLabel.size = new-object System.Drawing.Size(100,20)
$DropDownLabel.Text = ".\TSSv2.ps1"
$Form.Controls.Add($DropDownLabel)

$Button = new-object System.Windows.Forms.Button
$Button.Location = new-object System.Drawing.Size(100,90)
$Button.Size = new-object System.Drawing.Size(100,20)
$Button.Text = "Run Powershell"
$Button.Add_Click({senditdown})
$form.Controls.Add($Button)

$Button2 = new-object System.Windows.Forms.Button
$Button2.Location = new-object System.Drawing.Size(130,90)
$Button2.Size = new-object System.Drawing.Size(180,20)
$Button2.Text = "  Close"
$Button2.Add_Click({close-DropDown})
$form.Controls.Add($Button2)

$Form.Add_Shown({$Form.Activate()})
[void] $Form.ShowDialog()
[void] $Form.close()
 
 # directory for tssv2 is expected to be in the parent folder.
 # working directory shoudl be C:\Users\*user\Downloads\TSSv2\TSSv2GUI 

 ## POWER SHELL COMMAND RUN 
 
#$Patch = Join-Path -Path $PSScriptRoot -ChildPath "\tssv2.ps1"
#Invoke-Expression "& `".\$Patch`""

#start "$PSScriptRoot\tssv2.ps1 -scenario " @ZAEventLogDataSplat


#set-location -Path $PSScriptRoot
#$script2run = $pwd
#$destination = Split-Path -Path $script2run -Parent
#set-location $destination
#$build1 = ".\TssV2.ps1" 
#$final = $build1 + " -scenario"+ " $script:Choice"

Start-Process -FilePath "C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe" -ArgumentList "-NoProfile -NoLogo -noexit -ExecutionPolicy Bypass `"$script:final`" -ErrorAction Stop"
 
 
} 


  function collectlog
{

#[array]$DropDownArray2 = "-SDP All","-SDP Apps","-SDP Cluster","-SDP CTS","-SDP DA","-SDP Dom","-SDP DPM","-SDP HyperV","-SDP mini","-SDP nano","-SDP Net","-SDP Perf","-SDP Print","-SDP RDS","-SDP Repro","-SDP RFL","-SDP S2D","-SDP SCCM","-SDP Setup","-SDP SQLbase","-SDP SQLconn","-SDP SQLmsdtc","-SDP SQLsetup","-SDP SUVP","-SDP VSS" 
# This Function Returns the Selected Value and Closes the Form
#[array]$DropDownArray2 = "ADS_AccountLockout","ADS_Auth","ADS_Basic","ADS_ESR","ADS_OCSP","ADS_SBSL","DEV_Scn1","DEV_Scn2","DND_Servicing","NET_802Dot1x","NET_Auth","NET_BITS","NET_Bluetooth","NET_BranchCache","NET_Capture","NET_Container","NET_CSC","NET_DAcli","NET_DAsrv","NET_DFScli","NET_DFSsrv","NET_DHCPcli","NET_DHCPsrv","NET_DNScli","NET_DNSsrv","NET_Docker","NET_Firewall","NET_General","NET_HypHost","NET_IIS","NET_IPAM","NET_MBN","NET_MDM","NET_Miracast","NET_NCSI","NET_NETIO","NET_Netview","NET_NFScli","NET_NFSsrv","NET_NLB","NET_NPS","NET_PowerShell","NET_Proxy","NET_RAS","NET_RDMA","NET_RDScli","NET_RDSsrv","NET_RPC","NET_SBSL","NET_SdnNC","NET_SMB","NET_SMBcli","NET_SMBsrv","NET_SQLtrace","NET_UNChard","NET_VPN","NET_WebClient","NET_WebCliTTD","NET_WebIO","NET_WFP","NET_Winsock","NET_WIP","NET_WLAN","NET_WNV","NET_WorkFolders","PRF_Boot",  "PRF_Perflib","SHA_HypHost","SHA_HypVM","SHA_MScluster","UEX_Clipboard","UEX_Cortana","UEX_Logon","UEX_Photo","UEX_QuickAssist","UEX_Search","UEX_ServerManager","UEX_StartMenu","UEX_Store","UEX_Task","UEX_UWP","UEX_WinRM","UEX_WMI"


[array]$DropDownArray2 = "ADS_AccountLockout","ADS_ADCS","ADS_Auth","ADS_BadPwd","ADS_CEPCES","ADS_DFSr","ADS_GPedit","ADS_GPmgmt","ADS_GPO”,"ADS_GPsvc","ADS_GroupPolicy","ADS_LDAPsrv","ADS_LockOut","ADS_Netlogon","ADS_OCSP","ADS_Perf","ADS_Profile","ADS_SBSL","ADS_SSL","ADS_UserInfo","ADS_W32Time","DEV_TEST1","DEV_TEST2","DND_Servicing","DND_SETUP","DND_SETUPReport","DND_TPM","DND_WinUpd","DND_WULogs","NET_Auth","NET_BFE","NET_BITs","NET_Bluetooth","NET_BranchCache","NET_Container","NET_CSC","NET_DAcli","NET_DAsrv","NET_DFSsrv","NET_DHCPcli","NET_DHCPsrv","NET_DNScli","NET_DNSsrv","NET_Docker","NET_EFS","NET_Firewall","NET_GeoLocation","NET_HttpSys","NET_HypHost","NET_HypVM","NET_ICS","NET_IIS","NET_IPAM","NET_IPhlpSvc","NET_IPsec","NET_LBFO","NET_LDAPcli","NET_MBAM","NET_MBN","NET_Mdm","NET_MFAext","NET_Miracast","NET_NCSI","NET_Netlogon","NET_Netsetup","NET_NFScli","NET_NFSsrv","NET_NLB","NET_NPS","NET_OpenSSH","NET_Outlook","NET_PCI","NET_Perflib","NET_PnP","NET_PortProxy","NET_PowerShell","NET_PrintSvc","NET_Proxy","NET_QoS","NET_RAmgmt","NET_RAS","NET_RDMA","NET_RDScli","NET_RDScommon",`             
"NET_RDSsrv","NET_RPC","NET_SBSL","NET_SCCM","NET_SCM","NET_SdnNC","NET_SMBcli","NET_SMB","NET_SMBsrv","NET_SNMP","NET_SQLcheck","NET_TAPI","NET_TestMe","NET_UNChard","NET_VPN","NET_WebClient","NET_WebIO","NET_WFP","NET_WinRM ","NET_WIP","NET_WWAN","PRF_Perflib","SEC_DefenderFull","SEC_DefenderGet","SHA_HypHost","SHA_HypVM","SHA_SDDC","SHA_ShieldedVM","SHA_Sms","SHA_VML","UEX_AppCompat","UEX_AppV","UEX_AppX","UEX_Cortana","UEX_DSC","UEX_EventLog","UEX_Evt","UEX_Font","UEX_FSLogix","UEX_IME","UEX_Logon","UEX_Nls","UEX_PrintEx","UEX_Print","UEX_RDS","UEX_Sched ","UEX_Shell","UEX_StartMenu","UEX_Task","UEX_TSched","UEX_UEV","UEX_WinRM","UEX_WMI","ADS_AccountLockout","ADS_Auth","DEV_Scn1","DEV_Scn2","NET_802Dot1x","NET_Auth","NET_Mdm","NET_NetView","NET_TestMe","NET_WebCliTTD","NET_WLAN","NET_Workfolders","SHA_MsCluster"


[void] [System.Reflection.Assembly]::LoadWithPartialName("System.Windows.Forms")
[void] [System.Reflection.Assembly]::LoadWithPartialName("System.Drawing")
function senditdown {
$script:choicelog = $DropDown1.SelectedItem.ToString()
$Form.Close()

$script:choicelog

set-location -Path $PSScriptRoot
$script2run = $pwd
$destination = Split-Path -Path $script2run -Parent
set-location $destination
$build1 = ".\TssV2.ps1" 
$script:finalog = $build1 + " -collectlog"+ " $script:Choicelog"

#--------------------------------

clear-host
Write-host "The command you want to run is...  $final ... " -ForegroundColor Green


#$Patch = Join-Path -Path $PSScriptRoot -ChildPath "\tssv2.ps1"
#Invoke-Expression "& `".\$Patch`""

#start "$PSScriptRoot\tssv2.ps1 -scenario " @ZAEventLogDataSplat

Start-Process -FilePath "C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe" -ArgumentList "-NoProfile -NoLogo -noexit -ExecutionPolicy Bypass `"$script:finalog`" -ErrorAction Stop"

}

function close-DropDown {
$script:Choicelog = $DropDown1.SelectedItem.ToString()

$Form.Close()


}

###BEGIN MSDT WINDOW  
$Form = New-Object System.Windows.Forms.Form

$Form.width = 1200
$Form.height = 400
$Form.Text = ”.\TssV2 GUI”
## DROPDOWN TO CHOOSE COURSE OF COMMANDS 
$DropDown1 = new-object System.Windows.Forms.ComboBox
$DropDown1.Location = new-object System.Drawing.Size(120,40)
$DropDown1.Size = new-object System.Drawing.Size(190,60)

ForEach ($Item in $DropDownArray2) {
[void] $DropDown1.Items.Add($Item)
}

$Form.Controls.Add($DropDown1)

$DropDownLabel = new-object System.Windows.Forms.Label
$DropDownLabel.Location = new-object System.Drawing.Size(20,40)
$DropDownLabel.size = new-object System.Drawing.Size(100,20)
$DropDownLabel.Text = ".\TSSv2.ps1"
$Form.Controls.Add($DropDownLabel)

$Button = new-object System.Windows.Forms.Button
$Button.Location = new-object System.Drawing.Size(100,90)
$Button.Size = new-object System.Drawing.Size(100,20)
$Button.Text = "Run Powershell"
$Button.Add_Click({senditdown})
$form.Controls.Add($Button)

$Button2 = new-object System.Windows.Forms.Button
$Button2.Location = new-object System.Drawing.Size(130,90)
$Button2.Size = new-object System.Drawing.Size(180,20)
$Button2.Text = "  Close"
$Button2.Add_Click({close-DropDown})
$form.Controls.Add($Button2)

$Form.Add_Shown({$Form.Activate()})
[void] $Form.ShowDialog()
[void] $Form.close()
 
 # directory for tssv2 is expected to be in the parent folder.
 # working directory shoudl be C:\Users\*user\Downloads\TSSv2\TSSv2GUI 

 ## POWER SHELL COMMAND RUN 
 


}  

Function runcmd
{
  
[array]$DropDownArray2 = "-GPresult","-Handle","-LiveKD","-NetshScenario","-PerfMon","-PktMon","-PoolMon","-ProcDump", "-ProcMon"

# Not done yet "-PSR","-Radar","-RASdiag","-SDP","-SysMon","-TTD"   


[void] [System.Reflection.Assembly]::LoadWithPartialName("System.Windows.Forms")
[void] [System.Reflection.Assembly]::LoadWithPartialName("System.Drawing")
function senditdown {
$script:Choicewpr = $DropDown1.SelectedItem.ToString()
#$Form.Close()
 set-location -Path $PSScriptRoot
$script2run = $pwd
$destination = Split-Path -Path $script2run -Parent
set-location $destination
$build1 = ".\TssV2.ps1" 

If ($script:Choicewpr -eq "-PerfMon") {$script:final = $build1 + " $script:Choicewpr" + " General -PerfIntervalSec 20"}
If ($script:Choicewpr -eq "-NetshScenario") {$script:final = $build1 + " $script:Choicewpr" + " InternetClient_dbg"}
If ($script:Choicewpr -eq "-GPresult") {$script:final = $build1 + " $script:Choicewpr" + " start"}
If ($script:Choicewpr -eq "-Handle"){$script:final = $build1 + " $script:Choicewpr" + " start"}
If ($script:Choicewpr -eq "-LiveKD") {$script:final = $build1 + " $script:Choicewpr" + " Start"}
If ($script:Choicewpr -eq "-PktMon") {$script:final = $build1 + " $script:Choicewpr"}
If ($script:Choicewpr -eq "-PoolMon") {$script:final = $build1 + " $script:Choicewpr" + " start"}
If ($script:Choicewpr -eq "-ProcDump"){$pid = read-host "what is the PID?"; $script:final = $build1 + " $script:Choicewpr" + " $pid"}

If ($script:Choicewpr -eq "-PerfMon") {$script:final = $build1 + " $script:Choicewpr" + " General -PerfIntervalSec 20"}


#$script:final = $build1 + " $script:Choicewpr" +  " start"



Start-Process -FilePath "C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe" -ArgumentList "-NoProfile -NoLogo -noexit -ExecutionPolicy Bypass `"$script:final`" -ErrorAction Stop"

}

function close-DropDown {
$script:Choicewpr = $DropDown1.SelectedItem.ToString()

$Form.Close()


}

###BEGIN MSDT WINDOW  
$Form = New-Object System.Windows.Forms.Form


set-location -Path $PSScriptRoot
$script2run = $pwd
set-location $pwd 
$Image = [system.drawing.image]::FromFile("$($pwd)\Oryx_Antelope.jpg")
$Form.width = 1200
$Form.height = 400
$Form.Text = ”.\TssV2 GUI”
## DROPDOWN TO CHOOSE COURSE OF COMMANDS 
$Form.AutoSize = $false
$Form.BackgroundImage = $Image
$Form.BackgroundImageLayout = "None"
 # None, Tile, Center, Stretch, Zoom
$Form.Width = $Image.Width
$Form.Height = $Image.Height
$Font = New-Object System.Drawing.Font("Times New Roman",11,[System.Drawing.FontStyle]::Bold)
 # Font styles are: Regular, Bold, Italic, Underline, Strikeout
$Form.Font = $Font
$DropDown1 = new-object System.Windows.Forms.ComboBox
$DropDown1.Location = new-object System.Drawing.Size(120,40)
$DropDown1.Size = new-object System.Drawing.Size(190,60)

ForEach ($Item in $DropDownArray2) {
[void] $DropDown1.Items.Add($Item)
}

$Form.Controls.Add($DropDown1)

$DropDownLabel = new-object System.Windows.Forms.Label
$DropDownLabel.Location = new-object System.Drawing.Size(20,40)
$DropDownLabel.size = new-object System.Drawing.Size(100,20)
$DropDownLabel.Text = ".\TSSv2.ps1"
$Form.Controls.Add($DropDownLabel)

$Button = new-object System.Windows.Forms.Button
$Button.Location = new-object System.Drawing.Size(100,90)
$Button.Size = new-object System.Drawing.Size(100,20)
$Button.Text = "Run Powershell"
$Button.Add_Click({senditdown})
$form.Controls.Add($Button)

$Button2 = new-object System.Windows.Forms.Button
$Button2.Location = new-object System.Drawing.Size(130,90)
$Button2.Size = new-object System.Drawing.Size(180,20)
$Button2.Text = "  Close"
$Button2.Add_Click({close-DropDown})
$form.Controls.Add($Button2)

$Form.Add_Shown({$Form.Activate()})
[void] $Form.ShowDialog()
[void] $Form.close()
 
 # directory for tssv2 is expected to be in the parent folder.
 # working directory shoudl be C:\Users\*user\Downloads\TSSv2\TSSv2GUI 

 ## POWER SHELL COMMAND RUN 
 




}

Function Monitoring
{

Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
function senditdown {
$script:Choicemon = $DropdownMon.SelectedItem
#$monForm.Close()

}

function sendbackitEvent  {

$script:waitpoint =$Dropdownwait.selecteditem 
#$monForm.Close()
 
}




function close-DropDown {
$script:close = $DropdownMon.SelectedItem 

$monForm.Close()


}



#Clear-host
#Write-host "Welcome to the Monitoring Section! This will be an exciting way to select scopable criteria for collecting monitor logs!" 
#Write-host "THe Idea here is to choose the following:"
##Write-host " * Choose a component group"
#Write-host " * Choose a Component"
#Write-host " * Choose a Wait Event that will start collecting logs when the event occurs"
#Write-host " * Then when you start the log collection, the log will collect the scenario orcomponenent logs, when the event occurs. "
#Read-host " Are you ready to go? Hit a key to begin!"
#clear-host

#Write-host 


 function bloatshow {
    param (
        [string]$Title = 'My showboat Menu'
    )
    Clear-Host
    Write-Host "================ $Title ================"
    
    Write-Host "1: Press '1' Active Directory ADS"
    Write-Host "2: Press '2' Network NET"
    Write-Host "3: Press '3' Device and Deployment DND"
    Write-Host "4: Press '4' User Experience UEX"
    Write-Host "5: Press '5' Performance PRF"
    Write-Host "6: Press '6' Security SEC"
    Write-Host "7: Press '7' StorageandCluster SHA"
    Write-Host "8: Press '8' Other OTH"


     
}
 
 
 
    bloatshow
     $selection = Read-Host "Please make a selection"
     switch ($selection)
     {    
           '1' {'Active Directory ADS'
             $myanswer= "Active Directory ADS"
             [array]$ScenarioDropMon ="ADS_AccountLockout","ADS_ADCS","ADS_Auth","ADS_BadPwd","ADS_CEPCES","ADS_DFSr","ADS_GPedit","ADS_GPmgmt","ADS_GPO","ADS_GPsvc","ADS_GroupPolicy","ADS_LDAPsrv","ADS_LockOut","ADS_Netlogon","ADS_OCSP","ADS_Perf","ADS_Profile","ADS_SBSL","ADS_W32Time"  
       }   '2' {'Network NET'
            $myanswer= "Network NET"
            [array]$ScenarioDropMon ="NET_Auth","NET_BITs""NET_BranchCache","NET_Container","NET_DAcli""NET_DAsrv","NET_DFSsrv","NET_DHCPcli","NET_DHCPsrv","NET_DNScli","NET_DNSsrv","NET_Docker","NET_EFS","NET_Firewall","NET_GeoLocation","NET_HttpSys","NET_HypHost","NET_HypVM","NET_ICS","NET_IIS","NET_IPAM","NET_IPhlpSvc","NET_IPsec","NET_LBFO","NET_LDAPcli","NET_MBAM","NET_MBN","NET_Mdm","NET_MFAext","NET_NCSI","NET_RAS","NET_RDMA","NET_RDScli","NET_NFSsrv","NET_RDScommon","NET_RDSsrv","NET_RPC","NET_SBSL","NET_SCCM","NET_SCM","NET_SdnNC","NET_SMBcli","NET_SMB","NET_SMBsrv","NET_SNMP","NET_SQLcheck","NET_TAPI","NET_TLS","NET_UNChard","NET_VPN","NET_WebClient","NET_WebIO","NET_WFP","NET_WinRM","NET_WIP","NET_WWAN" 
         } '3' {'Device and Deployment DND'
             $myanswer = "Device and Deployment DND"
             [array]$ScenarioDropMon= "DND_Servicing","DND_SETUP","DND_SETUPReport","DND_TPM","DND_WinUpd","DND_WULogs"
         } '4' {'User Experience UEX'
              $myanswer= "User Experience UEX" 
               [array]$ScenarioDropMon= "UEX_AppCompat","UEX_AppX","UEX_Cortana","UEX_DSC","UEX_EventLog","UEX_Evt","UEX_Font","UEX_FSLogix","UEX_IME","UEX_Logon","UEX_Nls","UEX_PrintEx","UEX_Print","UEX_RDS","UEX_Sched","UEX_Shell","UEX_StartMenu","UEX_Task","UEX_TSched","UEX_UEV","UEX_WinRM","UEX_WMI"
        }  '5' {'Performance PRF'
             $myanswer= "Performance PRF"
              [array]$ScenarioDropMon = "PRF_Boot","PRF_Perflib","PRF_Sysadmin","PRF_RADAR"  
        }  '6' {'Security SEC'
             $myanswer= "Security SEC"
             [array]$ScenarioDropMon = "SEC_DefenderFull","SEC_DefenderGet"  
        } '7' {'StorageandCluster SHA'
             $myanswer= "StorageandCluster SHA"
             [array]$ScenarioDropMon = "SHA_HypHost","SHA_HypVM","SHA_SDDC","SHA_ShieldedVM","SHA_Sms","SHA_VML"
        }  '8' {
             'Other OTH'
             $myanswer="Other OTH"

        }   
        
         } 



[Array]$mywaitevent= "Evt","PortLoc","PortDest","Svc","Process","Share","SMB","HTTP","RDP","WINRM","LDAP","RegData","RegValue","RegKey","File","Time","HNSL2Tunnel","LogFile","StopCondition","HighCPU","HighMemory","Signal"



[void] [System.Reflection.Assembly]::LoadWithPartialName("System.Windows.Forms")
[void] [System.Reflection.Assembly]::LoadWithPartialName("System.Drawing")

# $monform is the main form 
# DropdownMon is the componenent combo box $ScenarioDropMon are the lists of scnarios in the first combo box
# $dropdownwait is the waitevent combo box $mywaitevent is the list of options for the second combo box
# Mywaitvalue is user typed in and must relate to the waitevent choice 

###BEGIN Main WINDOW  
$MonForm = New-Object System.Windows.Forms.Form

$MonForm.width = 1200
$MonForm.height = 400
$MonForm.Text = ”.\TssV2 GUI”
## DROPDOWN TO CHOOSE COURSE OF COMMANDS 
$DropdownMon = new-object System.Windows.Forms.ComboBox
$DropdownMon.Location = new-object System.Drawing.Size(100,40)
$DropdownMon.Size = new-object System.Drawing.Size(120,60)

ForEach ($Item in $ScenarioDropMon) {
[void] $DropdownMon.Items.Add($Item)
}

$MonForm.Controls.Add($DropdownMon)
# now add second combp box 

## DROPDOWN TO CHOOSE COURSE OF COMMANDS 
$Dropdownwait = new-object System.Windows.Forms.ComboBox
$Dropdownwait.Location = new-object System.Drawing.Size(320,40)
$Dropdownwait.Size = new-object System.Drawing.Size(100,70)

ForEach ($Itemwait in $mywaitevent) {
[void] $Dropdownwait.Items.Add($Itemwait)
}

$MonForm.Controls.Add($Dropdownwait)
# complete second combo box 
#-------------------------------------------------------------
$DropDownLabel = new-object System.Windows.Forms.Label
$DropDownLabel.Location = new-object System.Drawing.Size(20,40)
$DropDownLabel.size = new-object System.Drawing.Size(100,20)
$DropDownLabel.Text = ".\TSSv2.ps1"
$MonForm.Controls.Add($DropDownLabel)

$WaitLabel = new-object System.Windows.Forms.Label
$WaitLabel.Location = new-object System.Drawing.Size(230,40)
$WaitLabel.size = new-object System.Drawing.Size(100,20)
$WaitLabel.Text = "-WaitEvent"
$MonForm.Controls.Add($WaitLabel)

$Button = new-object System.Windows.Forms.Button
$Button.Location = new-object System.Drawing.Size(100,90)
$Button.Size = new-object System.Drawing.Size(130,20)
$Button.Text = "Component"
$Button.Add_Click({senditdown})
$MonForm.Controls.Add($Button)

$Button2 = new-object System.Windows.Forms.Button
$Button2.Location = new-object System.Drawing.Size(320,90)
$Button2.Size = new-object System.Drawing.Size(139,20)
$Button2.Text = "Wait Event"
$Button2.Add_Click({sendbackitEvent})
$MonForm.Controls.Add($Button2)

$CloseButton = new-object System.Windows.Forms.label
$CloseButton.Location = new-object System.Drawing.Size(130,160)
$CloseButton.Size = new-object System.Drawing.Size(700,80)
$Font = New-Object System.Drawing.Font("Times NewRoman",14,[System.Drawing.FontStyle]::Bold)
$CloseButton.font = $font
$CloseButton.Text = "Select drop downs from left to right then hit each button. OK to run command-"

$CloseButton.Add_Click({$monForm.Close()})
$MonForm.Controls.Add($CloseButton)


$Label = New-Object System.Windows.Forms.Label
$label.Font = $Font
$Label.Text = "The last text box is specific to the wait event.service name, port etc.."
$Label.BackColor = "Transparent"
$Label.AutoSize = $True
$monform.Controls.Add($Label)


$DropDownwabel = new-object System.Windows.Forms.Label
$DropDownwabel.Location = new-object System.Drawing.Size(20,40)
$DropDownwabel.size = new-object System.Drawing.Size(100,20)
$DropDownwabel.Text = "Wait Event"
$MonForm.Controls.Add($DropDownwabel)
# Once we activate we are waitign for answers and the powershell gets exectured from the button click
# this means the powershell exectution will need tooo be m

   ### Inserting the text box that will accept input
    $textBox = New-Object System.Windows.Forms.TextBox
    $textBox.Location = New-Object System.Drawing.Point(480,40) ### Location of the text box
    $textBox.Size = New-Object System.Drawing.Size(100,20) ### Size of the text box
    $textBox.Multiline = $false ### Allows multiple lines of data
    $textbox.AcceptsReturn = $true ### By hitting enter it creates a new line
    $textBox.ScrollBars = "Vertical" ### Allows for a vertical scroll bar if the list of text is too big for the window
    $textbox.Visible = $true
    $monform.Controls.Add($textBox)
  
    ### Adding an OK button to the text box window
    $OKButton = New-Object System.Windows.Forms.Button
    $OKButton.Location = New-Object System.Drawing.Point(480,80) ### Location of where the button will be
    $OKButton.Size = New-Object System.Drawing.Size(75,23) ### Size of the button
    $OKButton.Text = 'OK' ### Text inside the button
    $OKButton.DialogResult = [System.Windows.Forms.DialogResult]::OK

    $monform.AcceptButton = $OKButton
    $monform.Controls.Add($OKButton)

   ### Activates the form and sets the focus on it
   $MonForm.Add_Shown({$MonForm.Activate()})
$MonForm.Add_Shown({$textBox.Select()})
#-----------------------------------------------------

# [void] $MonForm.ShowDialog()




  $monform.ShowDialog() ### Displays the form 

 $script:array = $textbox.text


 $script:array = $textbox.text


 
set-location -Path $PSScriptRoot
$script2run = $pwd
$destination = Split-Path -Path $script2run -Parent
Set-Location $destination


$build1 = ".\TssV2.ps1" 

$final = $build1 + " -$script:Choicemon"+" -Waitevent "+"$script:waitpoint" + ":"+ "$script:array"
Write-host "$final"
Invoke-Expression  $final



}

 function runMSDT
{

[array]$DropDownArray2 = "-SDP All","-SDP Apps","-SDP Cluster","-SDP CTS","-SDP DA","-SDP Dom","-SDP DPM","-SDP HyperV","-SDP mini","-SDP nano","-SDP Net","-SDP Perf","-SDP Print","-SDP RDS","-SDP Repro","-SDP RFL","-SDP S2D","-SDP SCCM","-SDP Setup","-SDP SQLbase","-SDP SQLconn","-SDP SQLmsdtc","-SDP SQLsetup","-SDP SUVP","-SDP VSS" 
# This Function Returns the Selected Value and Closes the Form



[void] [System.Reflection.Assembly]::LoadWithPartialName("System.Windows.Forms")
[void] [System.Reflection.Assembly]::LoadWithPartialName("System.Drawing")
function senditdown {
$script:Choicemon = $DropDown1.SelectedItem.ToString()
$Form.Close()
  
 
 set-location -Path $PSScriptRoot
$script2run = $pwd
$destination = Split-Path -Path $script2run -Parent
set-location $destination
$build1 = ".\TssV2.ps1" 

$final = $build1 +" $script:Choicemon"
#Invoke-Expression  $final


#$Patch = Join-Path -Path $PSScriptRoot -ChildPath "\tssv2.ps1"
#Invoke-Expression "& `".\$Patch`""

#start "$PSScriptRoot\tssv2.ps1 -scenario " @ZAEventLogDataSplat

Start-Process -FilePath "C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe" -ArgumentList "-NoProfile -NoLogo -noexit -ExecutionPolicy Bypass `"$final`" -ErrorAction Stop"

}

function close-DropDown {
$script:Choicemon = $DropDown1.SelectedItem.ToString()

$Form.Close()


}

###BEGIN MSDT WINDOW  
$Form = New-Object System.Windows.Forms.Form

$Form.width = 1200
$Form.height = 400
$Form.Text = ”.\TssV2 GUI”
## DROPDOWN TO CHOOSE COURSE OF COMMANDS 
$DropDown1 = new-object System.Windows.Forms.ComboBox
$DropDown1.Location = new-object System.Drawing.Size(120,40)
$DropDown1.Size = new-object System.Drawing.Size(190,60)

ForEach ($Item in $DropDownArray2) {
[void] $DropDown1.Items.Add($Item)
}

$Form.Controls.Add($DropDown1)

$DropDownLabel = new-object System.Windows.Forms.Label
$DropDownLabel.Location = new-object System.Drawing.Size(20,40)
$DropDownLabel.size = new-object System.Drawing.Size(100,20)
$DropDownLabel.Text = ".\TSSv2.ps1"
$Form.Controls.Add($DropDownLabel)

$Button = new-object System.Windows.Forms.Button
$Button.Location = new-object System.Drawing.Size(100,90)
$Button.Size = new-object System.Drawing.Size(100,20)
$Button.Text = "Run Powershell"
$Button.Add_Click({senditdown})
$form.Controls.Add($Button)

$Button2 = new-object System.Windows.Forms.Button
$Button2.Location = new-object System.Drawing.Size(130,90)
$Button2.Size = new-object System.Drawing.Size(180,20)
$Button2.Text = "  Close"
$Button2.Add_Click({close-DropDown})
$form.Controls.Add($Button2)

$Form.Add_Shown({$Form.Activate()})
[void] $Form.ShowDialog()
[void] $Form.close()
 
 # directory for tssv2 is expected to be in the parent folder.
 # working directory shoudl be C:\Users\*user\Downloads\TSSv2\TSSv2GUI 

 ## POWER SHELL COMMAND RUN 
 




}

Function Wpr
{

[array]$DropDownArray2= "BootGeneral","CPU", "General","Graphic","Memory","Network","Registry","SQL","Storage","Wait","Xaml"



[void] [System.Reflection.Assembly]::LoadWithPartialName("System.Windows.Forms")
[void] [System.Reflection.Assembly]::LoadWithPartialName("System.Drawing")
function senditdown {
$script:Choicewpr = $DropDown1.SelectedItem.ToString()
$Form.Close()
 set-location -Path $PSScriptRoot
$script2run = $pwd
$destination = Split-Path -Path $script2run -Parent
set-location $destination
$build1 = ".\TssV2.ps1" 

$script:final = $build1 + " -Scenario" +" $script:Choicewpr" 




#$Patch = Join-Path -Path $PSScriptRoot -ChildPath "\tssv2.ps1"
#Invoke-Expression "& `".\$Patch`""

#start "$PSScriptRoot\tssv2.ps1 -scenario " @ZAEventLogDataSplat

Start-Process -FilePath "C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe" -ArgumentList "-NoProfile -NoLogo -noexit -ExecutionPolicy Bypass `"$script:final`" -ErrorAction Stop"

}

function close-DropDown {
$script:Choicewpr = $DropDown1.SelectedItem.ToString()

$Form.Close()


}

###BEGIN MSDT WINDOW  
$Form = New-Object System.Windows.Forms.Form

$Form.width = 1200
$Form.height = 400
$Form.Text = ”.\TssV2 GUI”
## DROPDOWN TO CHOOSE COURSE OF COMMANDS 
$DropDown1 = new-object System.Windows.Forms.ComboBox
$DropDown1.Location = new-object System.Drawing.Size(120,40)
$DropDown1.Size = new-object System.Drawing.Size(190,60)

ForEach ($Item in $DropDownArray2) {
[void] $DropDown1.Items.Add($Item)
}

$Form.Controls.Add($DropDown1)

$DropDownLabel = new-object System.Windows.Forms.Label
$DropDownLabel.Location = new-object System.Drawing.Size(20,40)
$DropDownLabel.size = new-object System.Drawing.Size(100,20)
$DropDownLabel.Text = ".\TSSv2.ps1"
$Form.Controls.Add($DropDownLabel)

$Button = new-object System.Windows.Forms.Button
$Button.Location = new-object System.Drawing.Size(100,90)
$Button.Size = new-object System.Drawing.Size(100,20)
$Button.Text = "Run Powershell"
$Button.Add_Click({senditdown})
$form.Controls.Add($Button)

$Button2 = new-object System.Windows.Forms.Button
$Button2.Location = new-object System.Drawing.Size(130,90)
$Button2.Size = new-object System.Drawing.Size(180,20)
$Button2.Text = "  Close"
$Button2.Add_Click({close-DropDown})
$form.Controls.Add($Button2)

$Form.Add_Shown({$Form.Activate()})
[void] $Form.ShowDialog()
[void] $Form.close()
 
 # directory for tssv2 is expected to be in the parent folder.
 # working directory shoudl be C:\Users\*user\Downloads\TSSv2\TSSv2GUI 

 ## POWER SHELL COMMAND RUN 
 




}

Function perfmon
{

[array]$DropDownArray2= “BC","BIZ","DC","General","HyperV","NC","NET","SHA_HyperV","SMB","SQL","UEX_IME”,"UEX_Print","UEX_RDS"


[void] [System.Reflection.Assembly]::LoadWithPartialName("System.Windows.Forms")
[void] [System.Reflection.Assembly]::LoadWithPartialName("System.Drawing")
function senditdown {
$script:Choiceperf = $DropDown1.SelectedItem.ToString()
$Form.Close()
 set-location -Path $PSScriptRoot
$script2run = $pwd
$destination = Split-Path -Path $script2run -Parent
set-location $destination
$build1 = ".\TssV2.ps1" 

$final = $build1 + " -PerfMon" +" $script:Choiceperf" + " -PerfIntervalSec 20"
 



#$Patch = Join-Path -Path $PSScriptRoot -ChildPath "\tssv2.ps1"
#Invoke-Expression "& `".\$Patch`""

#start "$PSScriptRoot\tssv2.ps1 -scenario " @ZAEventLogDataSplat

Start-Process -FilePath "C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe" -ArgumentList "-NoProfile -NoLogo -noexit -ExecutionPolicy Bypass `"$final`" -ErrorAction Stop"

}

function close-DropDown {
$script:Choiceperf = $DropDown1.SelectedItem.ToString()

$Form.Close()


}

###BEGIN MSDT WINDOW  
$Form = New-Object System.Windows.Forms.Form

$Form.width = 1200
$Form.height = 400
$Form.Text = ”.\TssV2 GUI”
## DROPDOWN TO CHOOSE COURSE OF COMMANDS 
$DropDown1 = new-object System.Windows.Forms.ComboBox
$DropDown1.Location = new-object System.Drawing.Size(120,40)
$DropDown1.Size = new-object System.Drawing.Size(190,60)

ForEach ($Item in $DropDownArray2) {
[void] $DropDown1.Items.Add($Item)
}

$Form.Controls.Add($DropDown1)

$DropDownLabel = new-object System.Windows.Forms.Label
$DropDownLabel.Location = new-object System.Drawing.Size(20,40)
$DropDownLabel.size = new-object System.Drawing.Size(100,20)
$DropDownLabel.Text = ".\TSSv2.ps1"
$Form.Controls.Add($DropDownLabel)

$Button = new-object System.Windows.Forms.Button
$Button.Location = new-object System.Drawing.Size(100,90)
$Button.Size = new-object System.Drawing.Size(100,20)
$Button.Text = "Run Powershell"
$Button.Add_Click({senditdown})
$form.Controls.Add($Button)

$Button2 = new-object System.Windows.Forms.Button
$Button2.Location = new-object System.Drawing.Size(130,90)
$Button2.Size = new-object System.Drawing.Size(180,20)
$Button2.Text = "  Close"
$Button2.Add_Click({close-DropDown})
$form.Controls.Add($Button2)

$Form.Add_Shown({$Form.Activate()})
[void] $Form.ShowDialog()
[void] $Form.close()
 
 # directory for tssv2 is expected to be in the parent folder.
 # working directory shoudl be C:\Users\*user\Downloads\TSSv2\TSSv2GUI 

 ## POWER SHELL COMMAND RUN 
 
 
#Invoke-Expression  $final

	 #  .\TSSv2.ps1 -PerfMon General -PerfIntervalSec 5
	  # .\TSSv2.ps1 -PerfMonLong SMB -PerfLongIntervalMin 11
}


# This Function Returns the Selected Value and Closes the Form

function killlogs
{

Read-host "We are running the log closer. Hit a key to exit"
invoke-expression ".\TSSv2.ps1 -stop -noBasiclog -noXray -verbose"


}

function turntopDropDown {
$script:Choicekil = $DropDown1.SelectedItem.ToString()
$Form.Close()

$script:Choicekil



#Show-Menu –Title 'My Menu'
 $selection = $script:Choicekil


 switch ($selection)
 {
     'runMSDT' {runMSDT}   
     'Runcmd'{Runcmd}
     'Monitoring'{Monitoring} 
     'Scenario'{scenario} 
     'collectlog'{collectlog} 
     'WPR' {WPR} 
     'Perfmon'{Perfmon} 
          
     }
 
}


[void] [System.Reflection.Assembly]::LoadWithPartialName("System.Windows.Forms")
[void] [System.Reflection.Assembly]::LoadWithPartialName("System.Drawing")

function TurntopAbort {
$script:Choice = $AbortDropDown.SelectedItem.ToString()


set-location -Path $PSScriptRoot
$script2run = $pwd
$destination = Split-Path -Path $script2run -Parent
set-location $destination
#$build1 = ".\TssV2.ps1" 

#$final = $build1 + " $script:Choice"
#Invoke-Expression  "$final"

 $Form.Close()
}


#START PROGRAM 

# Self-elevate the script if required
if (-Not ([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] 'Administrator')) {
 if ([int](Get-CimInstance -Class Win32_OperatingSystem | Select-Object -ExpandProperty BuildNumber) -ge 6000) {
  $CommandLine = "-File `"" + $MyInvocation.MyCommand.Path + "`" " + (update-parm $MyInvocation.BoundParameters) + " " + $MyInvocation.UnboundArguments
  Start-Process -FilePath PowerShell.exe -Verb Runas -ArgumentList $CommandLine
  Exit
 }
}


# Edit This item to change the DropDown Values

 ## "system","processor","volume","usb","computer","ports","diskdrive","wpd","monitor","keyboard","mouse","SCSIAdapter","HDC","Display","Cdrom","SoftwareDevice","SCSIAdapter","PrintQueue","SecurityDevices"

[array]$AbortArray = "-Status", "-stop", "-stopAutoLogger", "-RemoveAutoLogger", "-stopdiag", "-list", "-ListSupportedDiag", "-ListSupportedScenarioTrace","Killlogs"


[array]$menuArray = "runMSDT","Runcmd","Monitoring","scenario","collectlog","WPR","Perfmon"


[array]$DropDownArray2 = "-SDP All","-SDP Apps","-SDP Cluster","-SDP CTS","-SDP DA","-SDP Dom","-SDP DPM","-SDP HyperV","-SDP mini","-SDP nano","-SDP Net","-SDP Perf","-SDP Print","-SDP RDS","-SDP Repro","-SDP RFL","-SDP S2D","-SDP SCCM","-SDP Setup","-SDP SQLbase","-SDP SQLconn","-SDP SQLmsdtc","-SDP SQLsetup","-SDP SUVP","-SDP VSS" 
# Make Main Form 
$Form = New-Object System.Windows.Forms.Form

$Form.width = 782
$Form.height = 303
$Form.Text = ”.\TssV2 GUI”

# Make main dropdown 
$DropDown1 = new-object System.Windows.Forms.ComboBox
$DropDown1.Location = new-object System.Drawing.Size(82,29)
$DropDown1.Size = new-object System.Drawing.Size(133,19)

#Make abort dropdown

$AbortDropDown = new-object System.Windows.Forms.ComboBox
$AbortDropDown.Location = new-object System.Drawing.Size(82,155)
$AbortDropDown.Size = new-object System.Drawing.Size(146,19)

ForEach ($Item in $menuArray) {[void] $DropDown1.Items.Add($Item)}
ForEach ($Item in $AbortArray) {[void] $AbortDropDown.Items.Add($Item)}

#ADD main DROPDOWN MENU1
$Form.Controls.Add($DropDown1)
$Form.Controls.Add($AbortDropdown)

$DropDownLabel = new-object System.Windows.Forms.Label
$DropDownLabel.Location = new-object System.Drawing.Size(1,26)
$DropDownLabel.size = new-object System.Drawing.Size(115,32)
$DropDownLabel.Text = ".\TSSv2.ps1"
$Form.Controls.Add($DropDownLabel)

$AbortLabel = new-object System.Windows.Forms.Label
$AbortLabel.Location = new-object System.Drawing.Size(8,127)
$AbortLabel.size = new-object System.Drawing.Size(115,50)
$AbortLabel.Text = "Ways to Stop Collection"
$Form.Controls.Add($AbortLabel)

$Button = new-object System.Windows.Forms.Button
$Button.Location = new-object System.Drawing.Size(273,29)
$Button.Size = new-object System.Drawing.Size(240,29)
$Button.Text = "Choose Trace to start"
$Button.Add_Click({turntopDropDown})
$form.Controls.Add($Button)

$AbortButton = new-object System.Windows.Forms.Button
$AbortButton.Location = new-object System.Drawing.Size(235,151)
$AbortButton.Size = new-object System.Drawing.Size(160,25)
$AbortButton.Text = "Check Status or Stop"
$AbortButton.Add_Click({TurntopAbort})
$form.Controls.Add($AbortButton)

$DropDownLabel2 = new-object System.Windows.Forms.Label
$DropDownLabel2.Location = new-object System.Drawing.Size(20,10)
$DropDownLabel2.size = new-object System.Drawing.Size(100,20)
$DropDownLabel2.Text = "Run choices"
$Form.Controls.Add($DropDownLabel2)

$CloseButton = new-object System.Windows.Forms.label
$CloseButton.Location = new-object System.Drawing.Size(50,180)
$CloseButton.Size = new-object System.Drawing.Size(700,30)
$Font = New-Object System.Drawing.Font("Times NewRoman",16,[System.Drawing.FontStyle]::Bold)
$CloseButton.font = $font
$CloseButton.Text = "Monitoring takes you to powershell first-"

$CloseButton.Add_Click({$Form.Close()})
$Form.Controls.Add($CloseButton)

$msgButton = new-object System.Windows.Forms.label
$msgButton.Location = new-object System.Drawing.Size(50,210)
$msgButton.Size = new-object System.Drawing.Size(700,30)
$Font = New-Object System.Drawing.Font("Times NewRoman",16,[System.Drawing.FontStyle]::Bold)
$msgButton.font = $font
$msgButton.Text = "Use the Killlogs under check status or stop to clear failures"

$msgButton.Add_Click({$Form.Close()})
$Form.Controls.Add($msgButton)


$Form.Add_Shown({$Form.Activate()})
[void] $Form.ShowDialog()

$script:Choice



#Show-Menu –Title 'My Menu'
 $selection = $script:Choice

 switch ($selection)
 {
     'runMSDT' {runMSDT}   
     'Runcmd'{Runcmd}
     'Momitoring'{Monitoring} 
     'Scenario'{scenario} 
     'collectlog'{collectlog} 
     'WPR' {WPR} 
     'Perfmon'{Perfmon} 
          
     }  
     
     


 




